# 65th FA AI Toolkit

One Netlify site, two tools, one deploy.

| Path | Tool |
|---|---|
| `/` | Landing page linking both tools |
| `/staff-agents/` | 65th Artillery Agent Generator (fully static) |
| `/blueprint/` | BLUEPRINT Design Agent (static; optional live AI) |
| `/api/generate` | Optional edge function used by BLUEPRINT's AI mode |

## Deploy option A: drag and drop (both tools, copy mode)
1. Go to https://app.netlify.com/drop
2. Drag this whole folder onto the page.
3. Rename the site under Site configuration > Change site name.

Both tools work. BLUEPRINT runs in copy mode because drag-and-drop does not deploy edge functions.

## Deploy option B: GitHub or CLI (both tools + BLUEPRINT AI mode)
**GitHub:** push this folder to a repo, then Netlify > Add new site > Import an existing project.
Build command: blank. Publish directory: `.`

**CLI:** inside this folder run
```
npm install -g netlify-cli
netlify login
netlify deploy --prod
```

Then set environment variables (Site configuration > Environment variables, scope includes Functions) and redeploy:

| Name | Required | Value |
|---|---|---|
| ANTHROPIC_API_KEY | For AI mode | Key from console.anthropic.com |
| ACCESS_CODE | Strongly recommended | Passphrase users enter before generating |
| MODEL | No | Defaults to `claude-sonnet-5-5` |

Without ACCESS_CODE, anyone who finds the URL can spend your API credits.

## Updating
Replace the file you changed and redeploy (drag the folder again, push to GitHub, or `netlify deploy --prod`). Both tools update together.

## Use rules
- Commercial host: UNCLASSIFIED use only.
- Check with PAO before sharing the link widely; the site displays the unit insignia.
