// BLUEPRINT live AI endpoint (optional).
// GET  /api/generate -> { enabled, codeRequired, model }
// POST /api/generate -> streams the Claude Messages API response (server-sent events)
//
// Environment variables (Netlify > Site configuration > Environment variables, scope must include Functions):
//   ANTHROPIC_API_KEY  required to enable AI mode
//   ACCESS_CODE        strongly recommended; users must enter it before generating
//   MODEL              optional, defaults to claude-sonnet-5-5

const MAX_INPUT_CHARS = 60000;

export default async (request) => {
  const key = Netlify.env.get("ANTHROPIC_API_KEY");
  const code = Netlify.env.get("ACCESS_CODE");
  const model = Netlify.env.get("MODEL") || "claude-sonnet-5-5";

  if (request.method === "GET") {
    return Response.json({ enabled: Boolean(key), codeRequired: Boolean(code), model: key ? model : "" });
  }
  if (request.method !== "POST") {
    return new Response("Method not allowed", { status: 405, headers: { allow: "GET, POST" } });
  }
  if (!key) {
    return Response.json({ error: "AI is not configured on this site. Add ANTHROPIC_API_KEY in Netlify." }, { status: 503 });
  }

  let body;
  try { body = await request.json(); } catch { return Response.json({ error: "Request body must be JSON." }, { status: 400 }); }

  if (code && body.code !== code) {
    return Response.json({ error: "Access code is incorrect." }, { status: 401 });
  }
  const { system, prompt, stage } = body;
  if (typeof system !== "string" || typeof prompt !== "string" || !prompt.trim()) {
    return Response.json({ error: "Missing prompt." }, { status: 400 });
  }
  if (system.length + prompt.length > MAX_INPUT_CHARS) {
    return Response.json({ error: "Intake is too long. Shorten the text fields and try again." }, { status: 413 });
  }

  const upstream = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "x-api-key": key,
      "anthropic-version": "2023-06-01",
      "content-type": "application/json",
    },
    body: JSON.stringify({
      model,
      max_tokens: stage === "build" ? 16000 : 4000,
      stream: true,
      system,
      messages: [{ role: "user", content: prompt }],
    }),
  });

  if (!upstream.ok || !upstream.body) {
    const detail = (await upstream.text().catch(() => "")).slice(0, 300);
    const msg = upstream.status === 401 ? "The site's API key was rejected. Check ANTHROPIC_API_KEY."
      : upstream.status === 404 ? `Model "${model}" was not found. Check the MODEL setting.`
      : upstream.status === 429 ? "The AI service is rate-limiting this site. Wait a minute and try again."
      : `The AI service returned an error (${upstream.status}).`;
    return Response.json({ error: msg, detail }, { status: 502 });
  }

  // Pass the event stream straight through so long generations do not hit function time limits.
  return new Response(upstream.body, {
    headers: { "content-type": "text/event-stream; charset=utf-8", "cache-control": "no-cache" },
  });
};

export const config = { path: "/api/generate" };
